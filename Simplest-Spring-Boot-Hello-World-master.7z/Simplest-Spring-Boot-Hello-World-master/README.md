# Simplest-Spring-Boot-Hello-World
Simplest Spring Boot Hello World Example 


# Steps

> git clone https://github.com/goxr3plus/Simplest-Spring-Boot-Hello-World.git

> Run from your favourite IDE ( Eclipse , IntelliJ , Netbeans )

ENJOY THE POWER OF A HELLO WORLD ! Welcome to Spring Boot :)
