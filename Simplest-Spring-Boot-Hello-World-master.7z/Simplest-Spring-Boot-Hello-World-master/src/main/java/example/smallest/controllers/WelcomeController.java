package example.smallest.controllers;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class WelcomeController {
	
	@RequestMapping(method = RequestMethod.GET, produces = {"application/json"})
	public @ResponseBody String helloWorld() {
		Random random=new Random();
		StringBuffer buf=new StringBuffer();
		int c;
		while(buf.length()<8) {
			c=random.nextInt(36);
			if(c<10) {
				buf.append((char)(c+48));
			}
			else {
				buf.append((char)(c+87));
			}
		}
		return buf.toString();
	}
}
